This directory contains all the file templates required to register and provide transparency of development AISaE effort through the framework. See the guide for Registering Your Project for instructions.

* Copy the templates to the directory corresponding to your current stage (i.e. concept, prototype, release version development or operations)
* When you progress from one stage to the next you can either start afresh with blanks again or copy across from the previous stage to the new, and update the documents as you progress through the steps for development again.

The files should be filled out on your repo. Do not remove headings or any YAML.